<?php

return [
    'routes' => [
        ['name' => 'ajax#applications', 'url' => '/ajax/applications', 'verb' => 'GET'],
    ]
];
