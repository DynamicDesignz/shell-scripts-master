OC.L10N.register(
  "files_rightclick", {
    "Open folder" : "開啟資料夾",
    "Open file" : "開啟檔案",
    "Open in new tab" : "開啟於新分頁",
    "Edit file" : "編輯文件",
    "Read PDF" : "查看 PDF",
    "See picture" : "檢視圖片",
    "Open in Gallery" : "開啟於相簿",
    "Play" : "播放",
    "Stop playback" : "停止播放",
    "Watch" : "觀賞",
    "Share folder" : "分享此資料夾",
    "Share file" : "分享文件",
    "Select" : "選取",
    "Unselect" : "取消選取",
  },
  "nplurals=2; plural=(n > 1);"
);
