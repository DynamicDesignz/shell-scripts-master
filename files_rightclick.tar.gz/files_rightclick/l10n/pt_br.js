OC.L10N.register(
  "files_rightclick", {
    "Open folder" : "Abrir esta pasta",
    "Open file" : "Abrir este arquivo",
    "Open in new tab" : "Abrir em uma nova aba",
    "Edit file" : "Editar este arquivo",
    "Read PDF" : "Ler este PDF",
    "See picture" : "Ver esta imagem",
    "Open in Gallery" : "Abrir na Galeria",
    "Play" : "Comece a tocar",
    "Stop playback" : "Parar de tocar",
    "Watch" : "Comece a assistir",
    "Share folder" : "Compartilhar esta pasta",
    "Share file" : "Compartilhar este arquivo",
    "Select" : "Select",
    "Unselect" : "Unselect",
  },
  "nplurals=2; plural=(n > 1);"
);
