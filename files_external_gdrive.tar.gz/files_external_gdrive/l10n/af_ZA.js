OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive Toepopstelling",
    "Error verifying OAuth2 Code for " : "Fout tydens OAuth2-kodeverifiëring vir",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Stap 1 het misluk. Uitsondering: %s",
    "Step 2 failed. Exception: %s" : "Stap 2 het misluk. Uitsondering: %s"
},
"nplurals=2; plural=(n != 1);");
