OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive app configuratie",
    "Error verifying OAuth2 Code for " : "Fout bij verifiëren OAuth2 Code voor ",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Stap 1 is mislukt. Uitzondering: %s",
    "Step 2 failed. Exception: %s" : "Stap 2 is mislukt. Uitzondering: %s"
},
"nplurals=2; plural=(n != 1);");
