OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Configuración d'Aplicación Google Drive",
    "Error verifying OAuth2 Code for " : "Fallu verificando'l códigu d'OAuth pa",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Pasu 1 fallíu. Esceición: %s",
    "Step 2 failed. Exception: %s" : "Pasu 2 fallíu. Esceición: %s"
},
"nplurals=2; plural=(n != 1);");
