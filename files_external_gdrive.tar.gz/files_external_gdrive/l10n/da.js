OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive App konfiguration",
    "Error verifying OAuth2 Code for " : "Fejl ved verifikation af OAuth2 code for",
    "Google Drive" : "Google Drev",
    "Step 1 failed. Exception: %s" : "Trin 1 mislykkedes. Undtagelse: %s",
    "Step 2 failed. Exception: %s" : "Trin 2 mislykkedes. Undtagelse: %s"
},
"nplurals=2; plural=(n != 1);");
