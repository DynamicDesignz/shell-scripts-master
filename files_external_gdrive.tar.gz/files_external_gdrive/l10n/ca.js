OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Configuració de l'aplicatiu Google Drive",
    "Error verifying OAuth2 Code for " : "Error verificant el codi OAuth2 ",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "El pas 1 ha fallat. Excepció: %s",
    "Step 2 failed. Exception: %s" : "El pas 2 ha fallat. Excepció: %s"
},
"nplurals=2; plural=(n != 1);");
