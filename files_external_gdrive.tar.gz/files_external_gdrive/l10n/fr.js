OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Configuration de l'application Google Drive",
    "Error verifying OAuth2 Code for " : "Erreur de vérification du code OAuth2 pour",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "L’étape 1 a échoué. Erreur : %s",
    "Step 2 failed. Exception: %s" : "L’étape 2 a échoué. Erreur : %s"
},
"nplurals=2; plural=(n > 1);");
