OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive Programkonfiguration",
    "Error verifying OAuth2 Code for " : "Kunde inte verifiera OAuth2-kod för",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Steg 1 flaerade. Undantag: %s",
    "Step 2 failed. Exception: %s" : "Steg 2 falerade. Undantag: %s"
},
"nplurals=2; plural=(n != 1);");
