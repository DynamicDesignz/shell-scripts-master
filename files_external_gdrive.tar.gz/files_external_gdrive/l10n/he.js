OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "הגדרות יישום גוגל דרייב",
    "Error verifying OAuth2 Code for " : "שגיאה באימות קוד OAuth2 עבור ",
    "Google Drive" : "גוגל דרייב",
    "Step 1 failed. Exception: %s" : "שלב 1 נכשל. חריג: %s",
    "Step 2 failed. Exception: %s" : "שלב 2 נכשל. חריג: %s"
},
"nplurals=2; plural=(n != 1);");
