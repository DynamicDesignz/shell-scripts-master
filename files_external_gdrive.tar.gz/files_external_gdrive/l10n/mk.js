OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive Конфигурација",
    "Error verifying OAuth2 Code for " : "Грешка при верификација на OAuth2 кодот за",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Чекор 1 Неуспешен: %s",
    "Step 2 failed. Exception: %s" : "Чекор 2 Неуспешен: %s"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
