OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google 드라이브 앱 설정",
    "Error verifying OAuth2 Code for " : "다음의 OAuth2 코드 검증 오류",
    "Google Drive" : "Google 드라이브",
    "Step 1 failed. Exception: %s" : "1단계 실패. 예외: %s",
    "Step 2 failed. Exception: %s" : "2단계 실패. 예외: %s"
},
"nplurals=1; plural=0;");
