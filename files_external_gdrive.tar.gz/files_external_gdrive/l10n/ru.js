OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Настройка приложения Google Drive",
    "Error verifying OAuth2 Code for " : "Ошибка проверки кода OAuth2 для ",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Шаг 1 неудачен. Исключение: %s",
    "Step 2 failed. Exception: %s" : "Шаг 2 неудачен. Исключение: %s"
},
"nplurals=4; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<12 || n%100>14) ? 1 : n%10==0 || (n%10>=5 && n%10<=9) || (n%100>=11 && n%100<=14)? 2 : 3);");
