OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Configuración de Aplicación Google Drive",
    "Error verifying OAuth2 Code for " : "Error verificando el código para Oauth2",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Error en paso 1. Excepción: %s",
    "Step 2 failed. Exception: %s" : "Error en paso 2. Excepción: %s"
},
"nplurals=2; plural=(n != 1);");
