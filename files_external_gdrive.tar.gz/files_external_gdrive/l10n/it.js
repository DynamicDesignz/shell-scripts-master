OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Configurazione applicazione Google Drive",
    "Error verifying OAuth2 Code for " : "Errore di verifica del OAuth2 Code per",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Fase 1 non riuscita. Eccezione: %s",
    "Step 2 failed. Exception: %s" : "Fase 2 non riuscita. Eccezione: %s"
},
"nplurals=2; plural=(n != 1);");
