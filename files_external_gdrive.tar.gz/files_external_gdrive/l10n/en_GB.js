OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive App Configuration",
    "Error verifying OAuth2 Code for " : "Error verifying OAuth2 Code for ",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Step 1 failed. Exception: %s",
    "Step 2 failed. Exception: %s" : "Step 2 failed. Exception: %s"
},
"nplurals=2; plural=(n != 1);");
