OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Konfigurasi aplikasi Google Drive ",
    "Error verifying OAuth2 Code for " : "Gagal memverifikasi Kode OAuth2 untuk",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Langkah 1 gagal. Kecuali: %s",
    "Step 2 failed. Exception: %s" : "Langkah 2 gagal. Kecuali: %s"
},
"nplurals=1; plural=0;");
