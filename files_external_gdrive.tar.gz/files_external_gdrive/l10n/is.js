OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Uppsetning Google Drive forrits",
    "Error verifying OAuth2 Code for " : "Villa við að sannvotta OAuth2-kóða fyrir",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Skref 1 mistókst. Undantekning: %s",
    "Step 2 failed. Exception: %s" : "Skref 2 mistókst. Undantekning: %s"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
