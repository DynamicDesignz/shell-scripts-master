OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Konfiguracja aplikacji Google Drive",
    "Error verifying OAuth2 Code for " : "Błąd podczas weryfilacji kody OAuth2 dla",
    "Google Drive" : "Dysk Google",
    "Step 1 failed. Exception: %s" : "Krok 1 błędny. Błąd: %s",
    "Step 2 failed. Exception: %s" : "Krok 2 błędny. Błąd: %s"
},
"nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);");
