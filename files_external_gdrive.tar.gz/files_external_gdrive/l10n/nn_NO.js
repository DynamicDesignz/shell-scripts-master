OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive program konfigurasjon",
    "Error verifying OAuth2 Code for " : "Feil ved verifisering av OAuth2 kode for",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Steg 1 feila. Feil: %s",
    "Step 2 failed. Exception: %s" : "Steg 2 feila. Feil: %s"
},
"nplurals=2; plural=(n != 1);");
