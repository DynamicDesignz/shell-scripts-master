OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive Uygulama Yapılandırması",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Adım 1 başarısız. Özel durum: %s",
    "Step 2 failed. Exception: %s" : "Adım 2 başarısız. Özel durum: %s"
},
"nplurals=2; plural=(n > 1);");
