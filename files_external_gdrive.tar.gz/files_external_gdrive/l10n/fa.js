OC.L10N.register(
    "files_external_gdrive",
    {
    "Error verifying OAuth2 Code for " : "خطا در تأیید رمز OAuth2 برای",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "گام 1 ناموفق بود. خطا: %s",
    "Step 2 failed. Exception: %s" : "گام 2ناموفق بود. خطا: %s"
},
"nplurals=1; plural=0;");
