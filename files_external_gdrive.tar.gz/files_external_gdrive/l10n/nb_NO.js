OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Konfigurering av Google Disk-app",
    "Error verifying OAuth2 Code for " : "Feil ved verifisering av OAuth kode for",
    "Google Drive" : "Google Disk",
    "Step 1 failed. Exception: %s" : "Steg 1 feilet. Unntak: %s",
    "Step 2 failed. Exception: %s" : "Steg 2 feilet. Unntak: %s"
},
"nplurals=2; plural=(n != 1);");
