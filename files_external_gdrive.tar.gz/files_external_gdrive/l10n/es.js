OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Configuración de la app de Google Drive",
    "Error verifying OAuth2 Code for " : "Error verificando el código OAuth2 para",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "El paso 1 falló. Excepción: %s",
    "Step 2 failed. Exception: %s" : "El paso 2 falló. Excepción: %s"
},
"nplurals=2; plural=(n != 1);");
