OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive Alkalmazáskonfiguráció",
    "Error verifying OAuth2 Code for " : "Hiba az OAuth2 kód ellenőrzése miatt",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "1. lépés sikertelen. Kivétel:%s",
    "Step 2 failed. Exception: %s" : "A 2. lépés nem sikerült. Kivétel:%s"
},
"nplurals=2; plural=(n != 1);");
