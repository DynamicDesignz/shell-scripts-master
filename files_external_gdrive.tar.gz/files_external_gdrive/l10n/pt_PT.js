OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Configuração da aplicação Google Drive",
    "Error verifying OAuth2 Code for " : "Erro ao verificar o 'Código OAuth2' para",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Passo 1 falhou. Exceção: %s",
    "Step 2 failed. Exception: %s" : "Passo 2 falhou. Exceção: %s"
},
"nplurals=2; plural=(n != 1);");
