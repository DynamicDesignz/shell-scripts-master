OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Ρυθμίσεις εφαρμογής Google Drive",
    "Error verifying OAuth2 Code for " : "Σφάλμα κατά την επαλήθευση του κώδικα OAuth2 για",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Το βήμα 1 απέτυχε. Εξαίρεση: %s",
    "Step 2 failed. Exception: %s" : "Το βήμα 2 απέτυχε. Εξαίρεση: %s"
},
"nplurals=2; plural=(n != 1);");
