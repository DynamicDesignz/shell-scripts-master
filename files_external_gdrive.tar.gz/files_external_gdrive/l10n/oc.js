OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Configuracion de l'aplicacion Google Drive",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "L’etapa 1 a fracassat. Error : %s",
    "Step 2 failed. Exception: %s" : "L’etapa 2 a fracassat. Error : %s"
},
"nplurals=2; plural=(n > 1);");
