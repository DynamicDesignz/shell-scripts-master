OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "ตั้งค่าแอพฯ Google Drive",
    "Error verifying OAuth2 Code for " : "เกิดข้อผิดพลาดในการยืนยันรหัส OAuth2 สำหรับ",
    "Google Drive" : "กูเกิ้ลไดร์ฟ",
    "Step 1 failed. Exception: %s" : "ขั้นตอนที่ 1 ล้มเหลว ข้อยกเว้น: %s",
    "Step 2 failed. Exception: %s" : "ขั้นตอนที่ 2 ล้มเหลว ข้อยกเว้น: %s"
},
"nplurals=1; plural=0;");
