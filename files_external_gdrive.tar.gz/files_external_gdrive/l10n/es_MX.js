OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Configuración de la Aplicación Google Drive",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Paso 1 falló. Excepción: %s",
    "Step 2 failed. Exception: %s" : "Paso 2 falló. Excepción: %s"
},
"nplurals=2; plural=(n != 1);");
