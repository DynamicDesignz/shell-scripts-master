OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google disko programėlės konfigūracija",
    "Error verifying OAuth2 Code for " : "Klaida, patvirtinant OAuth2 kodą, skirtą  ",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "1 žingsnio klaida: %s",
    "Step 2 failed. Exception: %s" : "2 žingsnio klaida: %s"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && (n%100<10 || n%100>=20) ? 1 : 2);");
