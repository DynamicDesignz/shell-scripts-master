OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Налаштування додатку Google Drive",
    "Error verifying OAuth2 Code for " : "Помилка перевірки коду OAuth2 для ",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "1-й крок невдалий. Виключення: %s",
    "Step 2 failed. Exception: %s" : "2-й крок невдалий. Виключення: %s"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
