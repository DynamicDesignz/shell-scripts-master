OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Nastavitve programa Google Drive",
    "Error verifying OAuth2 Code for " : "Napaka overjanja kode OAuth2 za",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "1. korak je spodletel. Izjemna napaka: %s",
    "Step 2 failed. Exception: %s" : "2. korak je spodletel. Izjemna napaka: %s"
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");
