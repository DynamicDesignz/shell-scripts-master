OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Nastavení aplikace Disk Google",
    "Error verifying OAuth2 Code for " : "Chyba ověření OAuth2 kódu pro",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Selhal krok 1. Výjimka: %s",
    "Step 2 failed. Exception: %s" : "Selhal krok 2. Výjimka: %s"
},
"nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;");
