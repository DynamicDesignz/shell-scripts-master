OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Formësim i Aplikacionit Google Drive",
    "Error verifying OAuth2 Code for " : "Gabim në verifikimin e Kodit OAuth2 për",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Hapi 1 dështoi. Përjashtim: %s",
    "Step 2 failed. Exception: %s" : "Hapi 2 dështoi. Përjashtim: %s"
},
"nplurals=2; plural=(n != 1);");
