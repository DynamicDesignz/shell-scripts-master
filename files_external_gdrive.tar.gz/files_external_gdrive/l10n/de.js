OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive - App Konfiguration",
    "Error verifying OAuth2 Code for " : "OAuth2-Code Überprüfungsfehler bei",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Schritt 1 fehlgeschlagen. Fehlermeldung: %s",
    "Step 2 failed. Exception: %s" : "Schritt 2 fehlgeschlagen. Fehlermeldung: %s"
},
"nplurals=2; plural=(n != 1);");
