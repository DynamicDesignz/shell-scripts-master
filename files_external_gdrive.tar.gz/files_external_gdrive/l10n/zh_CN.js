OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive 应用配置",
    "Error verifying OAuth2 Code for " : "验证 OAuth2 代码错误于",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "步骤 1 失败。异常：%s",
    "Step 2 failed. Exception: %s" : "步骤 2 失败。异常：%s"
},
"nplurals=1; plural=0;");
