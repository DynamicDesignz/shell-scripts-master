OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google Drive -sovelluksen määritys",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Vaihe 1 epäonnistui. Poikkeus: %s",
    "Step 2 failed. Exception: %s" : "Vaihe 2 epäonnistui. Poikkeus: %s"
},
"nplurals=2; plural=(n != 1);");
