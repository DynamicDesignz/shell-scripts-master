OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google アプリ設定",
    "Error verifying OAuth2 Code for " : "のOAuth2コードで検証エラーです。",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "ステップ 1 の実行に失敗しました。例外: %s",
    "Step 2 failed. Exception: %s" : "ステップ 2 の実行に失敗しました。例外: %s"
},
"nplurals=1; plural=0;");
