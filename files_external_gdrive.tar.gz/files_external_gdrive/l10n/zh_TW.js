OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Google 雲端硬碟應用程式設定",
    "Error verifying OAuth2 Code for " : "驗證 OAuth2 代碼時發生錯誤",
    "Google Drive" : "Google 雲端硬碟",
    "Step 1 failed. Exception: %s" : "步驟 1 失敗，出現異常: %s",
    "Step 2 failed. Exception: %s" : "步驟 2 失敗，出現異常: %s"
},
"nplurals=1; plural=0;");
