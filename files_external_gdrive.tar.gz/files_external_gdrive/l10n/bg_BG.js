OC.L10N.register(
    "files_external_gdrive",
    {
    "Google Drive App Configuration" : "Настройки на Google Drive приложение",
    "Error verifying OAuth2 Code for " : "Грешка при проверката на на OAuth2 кодър за",
    "Google Drive" : "Google Drive",
    "Step 1 failed. Exception: %s" : "Стъпка 1 - неуспешна. Грешка: %s",
    "Step 2 failed. Exception: %s" : "Стъпка 2 - неуспешна. Грешка: %s"
},
"nplurals=2; plural=(n != 1);");
